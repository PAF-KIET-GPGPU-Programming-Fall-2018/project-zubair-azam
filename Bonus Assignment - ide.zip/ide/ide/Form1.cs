﻿using ICSharpCode.TextEditor.Document;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace ide
{
    public partial class Form1 : Form
    {
        public List<tpoint> region = new List<tpoint>();
        public Form1()
        {
            InitializeComponent();

            textEditorControl1.Document.FoldingManager.FoldingStrategy = new VariXFolding();
            // Update folding markers, call whenever you need to update the folding markers.
            // Especially when the text in the texteditor has been changed.
            textEditorControl1.Document.FoldingManager.UpdateFoldings(null, null);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //this.Text = textEditorControl1.Document.TotalNumberOfLines.ToString();

            textEditorControl1.ActiveTextAreaControl.TextArea.KeyUp += TextArea_KeyUp;
            textEditorControl1.Document.LineDeleted += Document_LineDeleted;


            textEditorControl1.Text = "";



        }

        private void TextArea_KeyUp(object sender, KeyEventArgs e)
        {
           
        }

        public void indent()
        {
            Invoke(new Action(() =>
            {
                textEditorControl1.Document.FoldingManager.FoldingStrategy = new VariXFolding();
                // Update folding markers, call whenever you need to update the folding markers.
                // Especially when the text in the texteditor has been changed.
                textEditorControl1.Document.FoldingManager.UpdateFoldings(null, null);

                textEditorControl2.Document.FoldingManager.FoldingStrategy = new VariXFolding();
                // Update folding markers, call whenever you need to update the folding markers.
                // Especially when the text in the texteditor has been changed.
                textEditorControl2.Document.FoldingManager.UpdateFoldings(null, null);
            }));
        }

        private void Document_LineDeleted(object sender, LineEventArgs e)
        {
            
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void textEditorControl2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            groupBox1.Visible = true;
            textBox1.Text = "";




        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textEditorControl1.ActiveTextAreaControl.TextArea.SelectionManager.SelectedText.ToString().Length > 0)
            {

                textEditorControl2.Text = "";
                textEditorControl2.Text = "__global__ void " + textBox1.Text + "(){\n\r\t" + textEditorControl1.ActiveTextAreaControl.TextArea.SelectionManager.SelectedText.ToString() + "\n\r}\n\r";
                textEditorControl2.Refresh();

                string y = textEditorControl1.Text.Replace(textEditorControl1.ActiveTextAreaControl.TextArea.SelectionManager.SelectedText.ToString(), textBox1.Text + "<<<,>>>();");

                textEditorControl1.Text = y;

                textEditorControl1.Refresh();

                label1.Text = textBox1.Text;
                groupBox1.Visible = false;
            }
            else
            {
                MessageBox.Show("No Text Selected");
                groupBox1.Visible = false;

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SaveFileDialog n = new SaveFileDialog();
            n.Filter = "Cuda Kernel (*.cu)|*.cu";
           

            if (n.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(n.FileName, textEditorControl2.Text);
            }




        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog n = new OpenFileDialog();
            n.ShowDialog();
            if (n.FileName != null)
            {
                if (n.FileName.Length > 0)
                {
                    textEditorControl1.Text = File.ReadAllText(n.FileName);
                }
            }
        }

        private void textEditorControl1_TextChanged(object sender, EventArgs e)
        {
            Thread n = new Thread(indent);
            n.Start();
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 13)
            {
                button2_Click(new object(), new EventArgs());

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SaveFileDialog n = new SaveFileDialog();
            n.Filter = "Cuda Main (*.cu)|*.cu";
            
            
            if (n.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(n.FileName, textEditorControl1.Text);
            }


        }

        private void textEditorControl2_TextChanged(object sender, EventArgs e)
        {

            Thread n = new Thread(indent);
            n.Start();
        }

        
    }

    public struct tpoint
    {
        public int start;
        public int end;

    }

    public class VariXFolding : IFoldingStrategy
    {
        /// <summary>
        /// Generates the foldings for our document.
        /// </summary>
        /// <param name="document">The current document.</param>
        /// <param name="fileName">The filename of the document.</param>
        /// <param name="parseInformation">Extra parse information, not used in this sample.</param>
        /// <returns>A list of FoldMarkers.</returns>
        public List<FoldMarker> GenerateFoldMarkers(IDocument document, string fileName, object parseInformation)
        {
            List<FoldMarker> list = new List<FoldMarker>();

            int start = 0;

            Stack<int> st = new Stack<int>();
            // Create foldmarkers for the whole document, enumerate through every line.
            for (int i = 0; i < document.TotalNumberOfLines; i++)
            {
                // Get the text of current line.
                string text = document.GetText(document.GetLineSegment(i));

                if (text.TrimStart().StartsWith("for(") || text.TrimStart().StartsWith("if(") || text.TrimStart().StartsWith("public(") || text.TrimStart().StartsWith("void(") || text.TrimStart().StartsWith("private(")||( text.TrimStart().IndexOf("(")>-1&& text.TrimStart().IndexOf(")") > -1)) // Look for method starts
                {
                    start = i;
                    st.Push(start);
                }
                if (text.Contains("}"))
                {// Look for method endings
                 // Add a new FoldMarker to the list.
                 // document = the current document
                 // start = the start line for the FoldMarker
                 // document.GetLineSegment(start).Length = the ending of the current line = the start column of our foldmarker.
                 // i = The current line = end line of the FoldMarker.
                 // 7 = The end column
                    try
                    {
                        int val = st.Pop();
                        list.Add(new FoldMarker(document, val, document.GetLineSegment(val).Length, i, 1));
                    }
                    catch (Exception e)
                    {


                    }
                }

            }

            return list;
        }

        //public List<FoldMarker> GenerateFoldMarkers(IDocument document, string fileName, object parseInformation)
        //{
        //    List<FoldMarker> list = new List<FoldMarker>();

        //    int start = 0;

        //    // Create foldmarkers for the whole document, enumerate through every line.
        //    for (int i = 0; i < document.TotalNumberOfLines; i++)
        //    {
        //        // Get the text of current line.
        //        string text = document.GetText(document.GetLineSegment(i));

        //        if (text.StartsWith("def")) // Look for method starts
        //            start = i;
        //        if (text.StartsWith("enddef;")) // Look for method endings
        //                                        // Add a new FoldMarker to the list.
        //                                        // document = the current document
        //                                        // start = the start line for the FoldMarker
        //                                        // document.GetLineSegment(start).Length = the ending of the current line = the start column of our foldmarker.
        //                                        // i = The current line = end line of the FoldMarker.
        //                                        // 7 = The end column
        //            list.Add(new FoldMarker(document, start, document.GetLineSegment(start).Length, i, 7));
        //    }

        //    return list;
        //}
    }
}
